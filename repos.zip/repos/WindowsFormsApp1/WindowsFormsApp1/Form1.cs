﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        
        public Form1()
        {
            InitializeComponent();
            InitializeDataGridView();
        }

        private void btnSelectFolder_Click(object sender, EventArgs e)
        {
                // Cria uma nova instância do FolderBrowserDialog
                using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
                {
                    // Exibe a caixa de diálogo de seleção de pasta
                    DialogResult result = folderDialog.ShowDialog();

                    // Se o usuário selecionou uma pasta e clicou em OK
                    if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(folderDialog.SelectedPath))
                    {
                        // Exibe o caminho da pasta selecionada no TextBox
                        txtFolderPath.Text = folderDialog.SelectedPath;

                        ListFilesInFolder(folderDialog.SelectedPath);
                    
                    }
                }
            
        }

        // Método para listar arquivos e informações no DataGridView
        private void ListFilesInFolder(string folderPath)
        {
            try
            {
                // Limpar o DataGridView antes de adicionar novos arquivos
                dgvFiles.Rows.Clear();

                // Obter todos os arquivos da pasta
                string[] files = Directory.GetFiles(folderPath);

                // Adicionar informações dos arquivos no DataGridView
                foreach (string file in files)
                {
                    FileInfo fileInfo = new FileInfo(file);

                    // Informações do arquivo
                    string fileName = fileInfo.Name;
                    long fileSize = fileInfo.Length / 1024; // Tamanho em KB
                    DateTime lastModified = fileInfo.LastWriteTime;

                    // Adicionar uma linha no DataGridView
                    dgvFiles.Rows.Add(fileName, fileSize, lastModified);
                }

                // Se não houver arquivos na pasta
                if (files.Length == 0)
                {
                    MessageBox.Show("Nenhum arquivo encontrado na pasta.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar arquivos: " + ex.Message);
            }
        }


        private void InitializeDataGridView()
        {
            dgvFiles.ColumnCount = 3;
            dgvFiles.Columns[0].Name = "Nome do Arquivo";
            dgvFiles.Columns[1].Name = "Tamanho (KB)";
            dgvFiles.Columns[2].Name = "Data de Modificação";

            // Configurar para ajustar o tamanho das colunas ao conteúdo
            dgvFiles.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }



        private void ProcessFiles(string folderPath)
        {
            string[] files = Directory.GetFiles(folderPath);

            using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=testeprojetos;Trusted_Connection=True;"))
            {
                connection.Open();

                foreach (string file in files)
                {
                    FileInfo fileInfo = new FileInfo(file);
                    string fileName = fileInfo.Name;
                    string fileAddress = fileInfo.FullName;
                    long fileSize = fileInfo.Length;
                    DateTime fileDate = fileInfo.LastWriteTime;

                    // Inserir dados na tabela SQL
                    string query = "INSERT INTO Arquivos (Nome, Endereco, Tamanho, DataDisponibilizacao) VALUES (@Nome, @Endereco, @Tamanho, @DataDisponibilizacao)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Nome", fileName);
                        command.Parameters.AddWithValue("@Endereco", fileAddress);
                        command.Parameters.AddWithValue("@Tamanho", fileSize);
                        command.Parameters.AddWithValue("@DataDisponibilizacao", fileDate);

                        command.ExecuteNonQuery();
                    }
                }
            }

            MessageBox.Show("Dados inseridos com sucesso.");
        }

        private void btnProccessFile_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFolderPath.Text))
            {
                MessageBox.Show("Selecione uma pasta primeiro.");
                return;
            }

            ProcessFiles(txtFolderPath.Text);
        }
    }
}
