import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OficioService } from '../services/oficio.service';

@Component({
  selector: 'app-oficio-list',
  templateUrl: './oficio-list.component.html',
  styleUrls: ['./oficio-list.component.css']
})
export class OficioListComponent implements OnInit {
  oficios: any[] = [];

  constructor(private oficioService: OficioService, private router: Router) {}

  ngOnInit(): void {
    this.loadOficios();
  }

  loadOficios(): void {
    this.oficioService.getOficios().subscribe((data: any[]) => {
      this.oficios = data;
    });
  }

  // Métodos públicos para navegação e outras ações
  goToCreateOficio(): void {
    this.router.navigate(['/oficio/create']);
  }

  editOficio(id: number): void {
    this.router.navigate([`/oficio/edit/${id}`]);
  }

  deleteOficio(id: number): void {
    if (confirm('Tem certeza de que deseja excluir este ofício?')) {
      this.oficioService.deleteOficio(id).subscribe(() => {
        this.loadOficios(); // Recarrega a lista após exclusão
      });
    }
  }
}
