import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OficioListComponent } from './oficio-list/oficio-list.component';
import { OficioFormComponent } from './oficio-form/oficio-form.component';

const routes: Routes = [
  { path: '', redirectTo: '/oficios', pathMatch: 'full' },
  { path: 'oficios', component: OficioListComponent },
  { path: 'oficio/create', component: OficioFormComponent },
  { path: 'oficio/edit/:id', component: OficioFormComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
