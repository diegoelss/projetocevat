import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OficioService } from '../services/oficio.service';

@Component({
  selector: 'app-oficio-form',
  templateUrl: './oficio-form.component.html',
  styleUrls: ['./oficio-form.component.css']
})
export class OficioFormComponent implements OnInit {
  oficio: any = {
    numero: '',
    nome: '',
    descricao: ''
  };
  selectedFile: File | null = null;
  isEditMode = false;
  oficioId: number | null = null;

  constructor(
    private oficioService: OficioService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Verificar se estamos no modo de edição
    this.route.params.subscribe((params) => {
      if (params['id']) {
        this.isEditMode = true;
        this.oficioId = params['id'];
        this.oficioService.getOficio(this.oficioId!).subscribe((data) => {
          this.oficio = data;
        });
      }
    });
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  onSubmit() {
    if (this.isEditMode && this.oficioId !== null) {
      // Editar ofício
      this.oficioService
        .updateOficio(this.oficioId!, this.oficio, this.selectedFile || undefined)
        .subscribe(() => {
          this.router.navigate(['/oficios']);
        });
    } else {
      // Criar novo ofício
      this.oficioService.createOficio(this.oficio, this.selectedFile!).subscribe(() => {
        this.router.navigate(['/oficios']);
      });
    }
  }
}
